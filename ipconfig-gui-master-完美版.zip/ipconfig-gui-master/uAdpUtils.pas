unit uAdpUtils;

interface

uses Windows,classes,dialogs;


const
  MAX_INTERFACE_NAME_LEN = 256;
  MAXLEN_PHYSADDR = 8;
  MAXLEN_IFDESCR = 256;
  MIB_IF_TYPE_OTHER = 1;
  MIB_IF_TYPE_ETHERNET = 6;
  MIB_IF_TYPE_TOKENRING = 9;
  MIB_IF_TYPE_FDDI = 15;
  MIB_IF_TYPE_PPP = 23;
  MIB_IF_TYPE_LOOPBACK = 24;
  MIB_IF_TYPE_SLIP = 28;
  MIB_IF_ADMIN_STATUS_UP = 1;
  MIB_IF_ADMIN_STATUS_DOWN = 2;
  MIB_IF_ADMIN_STATUS_TESTING = 3;
  MIB_IF_OPER_STATUS_NON_OPERATIONAL = 0;
  MIB_IF_OPER_STATUS_UNREACHABLE = 1;
  MIB_IF_OPER_STATUS_DISCONNECTED = 2;
  MIB_IF_OPER_STATUS_CONNECTING = 3;
  MIB_IF_OPER_STATUS_CONNECTED = 4;
  MIB_IF_OPER_STATUS_OPERATIONAL = 5;

type
  MIB_PHYSADDR = array [0 .. MAXLEN_PHYSADDR - 1] of Byte;
  MIB_IFDESCR = array [0 .. MAXLEN_IFDESCR - 1] of AnsiChar;
  MIB_ADPTName= array [0 .. MAX_INTERFACE_NAME_LEN - 1] of WCHAR;
  PMIB_IFROW = ^MIB_IFROW;

  MIB_IFROW = packed record
    wszName:MIB_ADPTName {array [0 .. MAX_INTERFACE_NAME_LEN - 1] of WCHAR};
    dwIndex,
    dwType,
    dwMtu{�������ӿڵ�����䵥Ԫ},
    dwSpeed{�ýӿڵ����������},
    dwPhysAddrLen: DWORD;
    bPhysAddr: MIB_PHYSADDR;
    dwAdminStatus, dwOperStatus, dwLastChange, dwInOctets, dwInUcastPkts,
      dwInNUcastPkts, dwInDiscards, dwInErrors, dwInUnknownProtos, dwOutOctets,
      dwOutUcastPkts, dwOutNUcastPkts, dwOutDiscards, dwOutErrors, dwOutQLen,
      dwDescrLen: DWORD;
    bDescr: MIB_IFDESCR;
  end;

  PMIB_IFTABLE = ^MIB_IFTABLE;

  MIB_IFTABLE = packed record
    dwNumEntries: DWORD;
    table: array [0 .. 0] of MIB_IFROW;
  end;

  TAdapterStatus = record
    dwType, dwOperStatus: DWORD;
    bDescr: MIB_IFDESCR;
    bAdptName:MIB_ADPTName;
  end;

  TAdapterStatuses = array of TAdapterStatus;
function GetIfTable(pIfTable: PMIB_IFTABLE; pdwSize: PULONG; bOrder: BOOL)
  : DWORD; stdcall; external 'iphlpapi.dll';
function GetAdapterTypeString(const dwType: DWORD): string;
function GetGetAdapterStatusString(const dwOperStatus: DWORD): string;


//���ķ���
procedure ScanAdapters(var AdapterStatuses: TAdapterStatuses);



implementation


var
  dwSize: DWORD;
  pMibIfTable: PMIB_IFTABLE;

function GetAdapterTypeString(const dwType: DWORD): string;
begin
  case dwType of
    MIB_IF_TYPE_OTHER:
      Result := '����';
    MIB_IF_TYPE_ETHERNET:
      Result := '��̫��';
    MIB_IF_TYPE_TOKENRING:
      Result := '���ƻ�';
    MIB_IF_TYPE_FDDI:
      Result := 'FDDI';
    MIB_IF_TYPE_PPP:
      Result := 'PPP';
    MIB_IF_TYPE_LOOPBACK:
      Result := '��·';
    MIB_IF_TYPE_SLIP:
      Result := 'SLIP';
  end;
end;

function GetGetAdapterStatusString(const dwOperStatus: DWORD): string;
begin
  case dwOperStatus of
    MIB_IF_OPER_STATUS_NON_OPERATIONAL:
      Result := '����';
    MIB_IF_OPER_STATUS_UNREACHABLE:
      Result := '���ɴ�';
    MIB_IF_OPER_STATUS_DISCONNECTED:
      Result := '�Ͽ�';
    MIB_IF_OPER_STATUS_CONNECTING:
      Result := '������';
    MIB_IF_OPER_STATUS_CONNECTED:
      Result := '������';
    MIB_IF_OPER_STATUS_OPERATIONAL:
      Result := '��ͨ';
  end;
end;

procedure ScanAdapters(var AdapterStatuses: TAdapterStatuses);
var
  dwRetVal: DWORD;
  num, i: Longint;
begin
  dwRetVal := GetIfTable(pMibIfTable, @dwSize, False);
  if dwRetVal = NO_ERROR then
  begin
    num := pMibIfTable^.dwNumEntries;
    if Length(AdapterStatuses) <> num then
      SetLength(AdapterStatuses, num);
    for i := Low(AdapterStatuses) to High(AdapterStatuses) do
    begin
      AdapterStatuses[i].dwType := pMibIfTable^.table[i].dwType;
      AdapterStatuses[i].dwOperStatus := pMibIfTable^.table[i].dwOperStatus;
      AdapterStatuses[i].bDescr := pMibIfTable^.table[i].bDescr;
      AdapterStatuses[i].bAdptName := pMibIfTable^.table[i].wszName;
    end;
  end;
end;



initialization

GetIfTable(nil, @dwSize, False);
GetMem(pMibIfTable, dwSize);

finalization

FreeMem(pMibIfTable);

end.
