unit MyLanIp;

interface
uses Windows,SysUtils;

type
  TlanIpInfo = record
    ipAddress: string;
  end;

  TMyLanIp = class
  public
    class function GetIPAddress(out lanIP: TLanIpInfo): boolean;
    class function GetLocalIP : string;
  end;

  ///<summary> ��ȡ������� </summary>
  function GetComputerName: string;
  ///<summary> ��ȡ�û��� </summary>
  function GetCurrentUserName: String;
  ///<summary> ��ȡ�û��� </summary>
  function GetCurrentUserdomain: String;

implementation

uses Winsock;

class function TMyLanIp.GetIPAddress(out lanIP: TLanIpInfo): boolean;
type
  pu_long = ^u_long;
var
  varTWSAData : TWSAData;
  varPHostEnt : PHostEnt;
  varTInAddr : TInAddr;
  namebuf : array [0..255] of AnsiChar;
begin
  if WSAStartup($101, varTWSAData) <> 0 then
  begin
    lanIP.ipAddress:= '<no data>';
    Result:= False;
  end
  else begin
    gethostname(namebuf, sizeof(namebuf));
    varPHostEnt       := gethostbyname(namebuf);
    varTInAddr.S_addr := u_long(pu_long(varPHostEnt^.h_addr_list^)^);
    lanIp.ipAddress   := inet_ntoa(varTInAddr);
  end;
  WSACleanup;
  Result:= True;
end;


//��ȡ����ip��ַ
class function TMyLanIp.GetLocalIP : string;
type
    TaPInAddr = array [0..10] of PInAddr;
    PaPInAddr = ^TaPInAddr;
var
    wVersionRequested : WORD;
    phe  : PHostEnt;
    pptr : PaPInAddr;
    Buffer : array [0..63] of ansichar;
    I    : Integer;
    GInitData      : TWSADATA;
begin
    wVersionRequested := Windows.MAKEWORD(1, 1);
    WSAStartup(wVersionRequested, GInitData);
    Result := '';
    GetHostName(Buffer, SizeOf(Buffer));
    phe :=GetHostByName(buffer);
    if phe = nil then Exit;
    pptr := PaPInAddr(Phe^.h_addr_list);
    I := 0;
    while pptr^[I] <> nil do begin
      result:=SysUtils.StrPas(inet_ntoa(pptr^[I]^));
      Inc(I);
    end;
    WSACleanup;
end;

function GetComputerName: string;
begin
  Result := SysUtils.GetEnvironmentVariable('COMPUTERNAME');
end;

function GetCurrentUserName: String;
var
  nSize: DWord;
begin
  nSize := 1024;
  SetLength(Result, nSize);
  if GetUserName(PChar(Result), nSize) then
    SetLength(Result, nSize - 1)
  else
    RaiseLastOSError;
end;

function GetCurrentUserdomain: String;
const
  DNLEN = 255;
var
  sid: PSID;
  sidSize: DWord;
  sidNameUse: DWord;
  domainNameSize: DWord;
  domainName: array [0 .. DNLEN] of Char;
begin
  Result := '';


  sidSize := 65536;
  GetMem(sid, sidSize);
  domainNameSize := DNLEN + 1;
  sidNameUse := SidTypeUser;
  try
    if LookupAccountName(nil, PChar(GetCurrentUserName), sid, sidSize, domainName,
      domainNameSize, sidNameUse) then
      Result := strpas(domainName);
  finally
    FreeMem(sid);
  end;
end;

end.
