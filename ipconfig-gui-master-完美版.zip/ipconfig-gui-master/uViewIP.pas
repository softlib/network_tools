unit uViewIP;

interface
uses MyIP,MyLanIp,dialogs;

type TAddressList=record
    ///<summary> ����IP </summary>
    PublicIP:string;
    ///<summary> ������IP </summary>
    AreaIP:string;
    ///<summary> ����IP </summary>
    LocalIP:string;//
end;

type
   TLanLonInfo=record
     Lan:double;
     Lon:double;
   end;

function GetIPInfo():TAddressList;
function GetLatLonInfo():TLanLonInfo;
function GetComputerName():string;
function GetUserdomain():string;
function GetCurrentUserName():string;
function GetComputerDomain():string;
function GetCPUProcessID():string;
function GetMasterBoardSN():string;
function GetBiosSN():string;
function GetCityName():string;
function GetIsp():string;

implementation
uses sysutils, app.cmd.utils;

function GetIPInfo():TAddressList;
var
 info: TIPInfo;
 lanIp: TLanIpInfo;
 al:TAddressList;
begin
  if TMyIP.GetInfo(info) then
  begin
    al.PublicIP:= info.IPAddress;
  end;
  if TMyLanIp.GetIpAddress(lanIp) then
  begin
    al.AreaIP:=lanIp.ipAddress;
    al.LocalIP:=TMyLanIp.GetLocalIP;
  end;
  result:=al;
end;


function GetLatLonInfo():TLanLonInfo;
var
 info: TIPInfo;
 LLI:TLanLonInfo;
begin
  LLI.Lan:=0;
  LLI.Lon:=0;
  if TMyIP.GetInfo(info) then
  begin
     LLI.Lan:=info.lat;
     LLI.Lon:=info.lon;
  end;

  result:=LLI;
end;

function GetComputerName():string;
begin
// ������� �� ������
  result:=MyLanIp.GetComputerName;
end;

function GetUserdomain():string;
begin
// �û���
  result:=MyLanIp.GetCurrentUserdomain;
end;

function GetCurrentUserName():string;
begin
// �û���
  result:=MyLanIp.GetCurrentUserName;
end;

function GetComputerDomain():string;
var
 MyDomain: string;
begin
  //��ȡ������������������߼����������������
  app.cmd.utils.ExecuteCommandLine('wmic computersystem get domain',MyDomain);
  MyDomain:=stringreplace(MyDomain,'domain','',[rfReplaceAll, rfIgnoreCase]);
  MyDomain:=stringreplace(MyDomain,slinebreak,'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,'','',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(160),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(13),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(10),'',[rfReplaceAll]);
  result:=trim(MyDomain);
end;

function GetCPUProcessID():string;
var
 MyDomain: string;
begin
  //��ȡCPU���к�
  app.cmd.utils.ExecuteCommandLine('wmic cpu get processorid',MyDomain);
  MyDomain:=stringreplace(MyDomain,'processorid','',[rfReplaceAll, rfIgnoreCase]);
  MyDomain:=stringreplace(MyDomain,slinebreak,'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,'','',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(160),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(13),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(10),'',[rfReplaceAll]);
  result:=trim(MyDomain);
end;

function GetMasterBoardSN():string;
var
 MyDomain: string;
begin
  //��ȡ�������к�
  app.cmd.utils.ExecuteCommandLine('wmic baseboard get serialnumber',MyDomain);
  MyDomain:=stringreplace(MyDomain,'serialnumber','',[rfReplaceAll, rfIgnoreCase]);
  MyDomain:=stringreplace(MyDomain,slinebreak,'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,'','',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(160),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(13),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(10),'',[rfReplaceAll]);
  result:=trim(MyDomain);
end;

function GetBiosSN():string;
var
 MyDomain: string;
begin
  //��ȡBIOS���к�
  app.cmd.utils.ExecuteCommandLine('wmic bios get serialnumber',MyDomain);
  MyDomain:=stringreplace(MyDomain,'serialnumber','',[rfReplaceAll, rfIgnoreCase]);
  MyDomain:=stringreplace(MyDomain,slinebreak,'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,'','',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(160),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(13),'',[rfReplaceAll]);
  MyDomain:=stringreplace(MyDomain,char(10),'',[rfReplaceAll]);
  result:=trim(MyDomain);
end;


function GetCityName():string;
var
 info: TIPInfo;
begin
// ���ڳ���
  if TMyIP.GetInfo(info) then
     result:=info.city;
end;

function GetIsp():string;
var
 info: TIPInfo;
begin
// �����������ṩ��
  if TMyIP.GetInfo(info) then
     result:=info.Isp;
end;

initialization
 showmessage(GetIPInfo.PublicIP);



end.
