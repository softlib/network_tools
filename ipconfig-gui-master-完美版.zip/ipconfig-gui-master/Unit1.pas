unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Buttons, Mask, ExtCtrls, shellapi, Spin, XPMan, RzStatus, RzPanel, Vcl.ComCtrls;

type
  TMainForm = class(TForm)
    BitBtn1: TBitBtn;
    GroupBox1: TGroupBox;
    GroupBox2: TGroupBox;
    CheckBox1: TCheckBox;
    Label1: TLabel;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    Bevel1: TBevel;
    CheckBox6: TCheckBox;
    Timer1: TTimer;
    Label2: TLabel;
    SpinEdit1: TSpinEdit;
    SpinEdit2: TSpinEdit;
    SpinEdit3: TSpinEdit;
    SpinEdit4: TSpinEdit;
    SpinEdit5: TSpinEdit;
    SpinEdit6: TSpinEdit;
    SpinEdit7: TSpinEdit;
    SpinEdit8: TSpinEdit;
    Label3: TLabel;
    SpinEdit9: TSpinEdit;
    SpinEdit10: TSpinEdit;
    SpinEdit11: TSpinEdit;
    SpinEdit12: TSpinEdit;
    Label4: TLabel;
    SpinEdit13: TSpinEdit;
    SpinEdit14: TSpinEdit;
    SpinEdit15: TSpinEdit;
    SpinEdit16: TSpinEdit;
    Label5: TLabel;
    SpinEdit17: TSpinEdit;
    SpinEdit18: TSpinEdit;
    SpinEdit19: TSpinEdit;
    SpinEdit20: TSpinEdit;
    SpeedButton1: TSpeedButton;
    ComboBox1: TComboBox;
    SpeedButton2: TSpeedButton;
    StatusBar1: TStatusBar;
    Button1: TButton;
    procedure BitBtn1Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);

    procedure SpeedButton1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ComboBox1CloseUp(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure SpinEdit1MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure SpeedButton2Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
   procedure DoSpinEditEnter(Sender: TObject);
   procedure DoSpinEditKeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
  public
    { Public declarations }
    procedure FetchAdpInfo();
    function CheckNetworkConnectivity():boolean;
  end;

var
  MainForm: TMainForm;
  cmd1, cmd2: string;
  data: TStrings;

implementation

uses uAdpUtils, uGetAdapterInfo,
  uNetworkConnection,strutils,upxWinUtils
  ,upxPingSupportIPV6
  ,uGetAdapterInfo_V2;

{$R *.dfm}

procedure RunFile(const AFile:string;aCmdShow:boolean);
var
 strExecute:AnsiString;
begin
 // cmd /c dir ��ִ����dir�����ر������
 // cmd /k dir ��ִ����dir����󲻹ر������
 // cmd /c start dir ���һ���´��ں�ִ��dirָ�ԭ���ڻ�رա�
 //cmd /k start dir ���һ���´��ں�ִ��dirָ�ԭ���ڲ���رա�

 strExecute:=AnsiString(Format('cmd.exe /c start %s',[AFile]));
 if Not aCmdShow then
   WinExec(PAnsiChar(strExecute),SW_HIDE)
 else
   WinExec(PAnsiChar(strExecute),SW_SHOWNORMAL);
end;

procedure RunCMD(const ACmdLine:string;aShowWin:boolean);
var
 strExecute:AnsiString;
begin
 strExecute:=AnsiString(Format('cmd.exe %s',[ACmdLine]));
 if Not aShowWin then
   WinExec(PAnsiChar(strExecute),SW_HIDE)
 else
   WinExec(PAnsiChar(strExecute),SW_SHOWNORMAL);
end;

procedure TMainForm.BitBtn1Click(Sender: TObject);
begin
  //IP��ַ����������
   BitBtn1.Enabled:=false;

  if CheckBox1.Checked then
    cmd1 := '/c netsh interface ip set address "' + ComboBox1.Text + '" static ' +
      SpinEdit1.Text + '.' + SpinEdit2.Text + '.' + SpinEdit3.Text + '.' +
      SpinEdit4.Text + ' ' + SpinEdit5.Text + '.' + SpinEdit6.Text + '.' +
      SpinEdit7.Text + '.' + SpinEdit8.Text;
  RunCMD(cmd1,false);


  //Ĭ������
  if CheckBox2.Checked then
    cmd1 := '/c netsh interface ip set address "' + ComboBox1.Text + '" static ' +
      SpinEdit1.Text + '.' + SpinEdit2.Text + '.' + SpinEdit3.Text + '.' +
      SpinEdit4.Text + ' ' + SpinEdit5.Text + '.' + SpinEdit6.Text + '.' +
      SpinEdit7.Text + '.' + SpinEdit8.Text + ' ' + SpinEdit9.Text + '.' +
      SpinEdit10.Text + '.' + SpinEdit11.Text + '.' + SpinEdit12.Text;

   RunCMD(cmd1,false);

  // ��ѡDNS������
  if CheckBox3.Checked then
    cmd2 := '/c netsh interface ip set dns "' + ComboBox1.Text + '" static ' +
      SpinEdit13.Text + '.' + SpinEdit14.Text + '.' + SpinEdit15.Text + '.' +SpinEdit16.Text + ' primary';

    RunCMD(cmd2,false);

  // ����DNS������
  if CheckBox4.Checked then
    cmd1 := '/c netsh interface ip add dnsservers "' + ComboBox1.Text + '" ' +
     SpinEdit13.Text+'.'+SpinEdit14.Text+'.'+SpinEdit15.Text+'.'+SpinEdit16.Text+' '+
      SpinEdit17.Text + '.' + SpinEdit18.Text + '.' + SpinEdit19.Text + '.' +
      SpinEdit20.Text;

   RunCMD(cmd1,false);

   //�Զ���ȡ
   if CheckBox5.Checked then cmd1:='/c netsh interface ip set address "'+ComboBox1.Text+'" dhcp ';
   if CheckBox6.Checked then cmd2:='/c netsh interface ip set dns "'+ComboBox1.Text+'" dhcp';

  RunCMD(cmd1,false);
  RunCMD(cmd2,false);
  sleep(1500);
  ShowMessage('������ϣ�');
  SpeedButton2Click(nil);

  BitBtn1.Enabled:=true;
end;

type
  TPhysicalAdapterInfo=record
    AdapterDisplay:string;
    IPAddress:string;
    Subnetmask:string;
    Gateway:string;
    EnableDHCP:Boolean;
  end;

 TPhysicalAdapterInfoList=TArray<TPhysicalAdapterInfo> ;

 function GetAdapterDisplay(Const AdaptGUID:string):string;
var
  linkList: TStrings;
  sinfo, AdptGUID: string;
  i: integer;
begin
  linkList := tstringlist.Create;
  try
    uNetworkConnection.GetConnectionList(linkList);
    for i := 0 to linkList.Count - 1 do
    begin
      AdptGUID := copy(linkList[i], 1, pos('|', linkList[i]) - 1);
      if uGetAdapterInfo.IsPhysicalAdapter(AdptGUID) and (AdaptGUID=AdptGUID) then
      begin
         Exit(linkList[i].Split(['|'])[1]);
      end;
    end;
  finally
    FreeAndNil(linkList);
  end;
end;

function GetCurrentPhysicalAdapterInfo(var AdapterDisplayList:TStrings):TPhysicalAdapterInfoList;
var
  infos: TList;
  i:integer;
  adapInfo:TPhysicalAdapterInfo;
begin
  infos := uGetAdapterInfo.GetAdapterInfo;
  SetLength(Result,0);
  for i := 0 to infos.Count-1 do
  begin
    if IsPhysicalAdapter(TAdapterInfo(infos.Items[i]).AdapterGUID)
      and (pos('usb',lowercase(TAdapterInfo(infos.Items[i]).AdapterName))=0)
      and (pos('wireless',lowercase(TAdapterInfo(infos.Items[i]).AdapterName))=0)
      and (pos('vpn',lowercase(TAdapterInfo(infos.Items[i]).AdapterName))=0)
      and (pos('vmware',lowercase(TAdapterInfo(infos.Items[i]).AdapterName))=0)
      and (pos('virtualbox',lowercase(TAdapterInfo(infos.Items[i]).AdapterName))=0)
      and (pos('virtual',lowercase(TAdapterInfo(infos.Items[i]).AdapterName))=0)
      and (pos('tap-windows',lowercase(TAdapterInfo(infos.Items[i]).AdapterName))=0)
       then
    begin
      if Not TAdapterInfo(infos.Items[i]).DHCP then //�ֶ�
      begin
      // showmessage('��ǰ�������� '+TAdapterInfo(infos.Items[i]).AdapterGUID+' ='+TAdapterInfo(infos.Items[i]).AdapterName);
      { Result.AdapterDisplay:= GetAdapterDisplay(TAdapterInfo(infos.Items[i]).AdapterGUID);
       Result.IPAddress:=TAdapterInfo(infos.Items[i]).IPAddress;
       Result.Subnetmask:=TAdapterInfo(infos.Items[i]).Subnetmask;
       Result.Gateway:=TAdapterInfo(infos.Items[i]).Gateway;
       Result.EnableDHCP:=TAdapterInfo(infos.Items[i]).DHCP;
       AdapterDisplayList.Add(GetAdapterDisplay(TAdapterInfo(infos.Items[i]).AdapterGUID));
       }

      // showmessage(TAdapterInfo(infos.Items[i]).IPAddress);

       adapInfo.AdapterDisplay:= GetAdapterDisplay(TAdapterInfo(infos.Items[i]).AdapterGUID);
       adapInfo.IPAddress:=TAdapterInfo(infos.Items[i]).IPAddress;
       adapInfo.Subnetmask:=TAdapterInfo(infos.Items[i]).Subnetmask;
       adapInfo.Gateway:=TAdapterInfo(infos.Items[i]).Gateway;
       adapInfo.EnableDHCP:=TAdapterInfo(infos.Items[i]).DHCP;
       AdapterDisplayList.Add(GetAdapterDisplay(TAdapterInfo(infos.Items[i]).AdapterGUID));

       SetLength(Result,length(Result)+1);
       Result[high(Result)]:=adapInfo;

      end
      else
      begin
         adapInfo.AdapterDisplay:= GetAdapterDisplay(TAdapterInfo(infos.Items[i]).AdapterGUID);
         adapInfo.IPAddress:=TAdapterInfo(infos.Items[i]).IPAddress;
         adapInfo.Subnetmask:=TAdapterInfo(infos.Items[i]).Subnetmask;
         adapInfo.Gateway:=TAdapterInfo(infos.Items[i]).Gateway;
         adapInfo.EnableDHCP:=TAdapterInfo(infos.Items[i]).DHCP;
         AdapterDisplayList.Add(GetAdapterDisplay(TAdapterInfo(infos.Items[i]).AdapterGUID));

         SetLength(Result,length(Result)+1);
         Result[high(Result)]:=adapInfo;
      end;
    end
    else
      begin
       //  AdapterDisplayList.Add(GetAdapterDisplay(TAdapterInfo(infos.Items[i]).AdapterGUID));
      end;
  end;

  infos.Clear;
  infos.free;
end;


procedure TMainForm.ComboBox1CloseUp(Sender: TObject);
var
 AdapterDisplayList:TStrings;
 adptList:TPhysicalAdapterInfoList;
 adptinfo:TPhysicalAdapterInfo;
begin
  if ComboBox1.ItemIndex<>-1 then
  begin
   {//Version 1
    AdapterDisplayList:=TStringList.Create;
    try
      adptList:=GetCurrentPhysicalAdapterInfo(AdapterDisplayList);


      if Length(adptList)>0 then
      for adptinfo in adptList do
      begin
         if ComboBox1.text=adptinfo.AdapterDisplay then
         begin
           SpinEdit1.Text:=adptinfo.IPAddress.Split(['.'])[0];
           SpinEdit2.Text:=adptinfo.IPAddress.Split(['.'])[1];
           SpinEdit3.Text:=adptinfo.IPAddress.Split(['.'])[2];
           SpinEdit4.Text:=adptinfo.IPAddress.Split(['.'])[3];

           SpinEdit5.Text:=adptinfo.Subnetmask.Split(['.'])[0];
           SpinEdit6.Text:=adptinfo.Subnetmask.Split(['.'])[1];
           SpinEdit7.Text:=adptinfo.Subnetmask.Split(['.'])[2];
           SpinEdit8.Text:=adptinfo.Subnetmask.Split(['.'])[3];

           SpinEdit9.Text:=adptinfo.Gateway.Split(['.'])[0];
           SpinEdit10.Text:=adptinfo.Gateway.Split(['.'])[1];
           SpinEdit11.Text:=adptinfo.Gateway.Split(['.'])[2];
           SpinEdit12.Text:=adptinfo.Gateway.Split(['.'])[3];

           SpinEdit13.Text:=adptinfo.Gateway.Split(['.'])[0];
           SpinEdit14.Text:=adptinfo.Gateway.Split(['.'])[1];
           SpinEdit15.Text:=adptinfo.Gateway.Split(['.'])[2];
           SpinEdit16.Text:=adptinfo.Gateway.Split(['.'])[3];


           CheckBox5.Checked:=adptinfo.EnableDHCP;
           CheckBox6.Checked:=adptinfo.EnableDHCP;

           ComboBox1.Items.Assign(AdapterDisplayList);
           ComboBox1.ItemIndex:=ComboBox1.Items.IndexOf(adptinfo.AdapterDisplay);


         end;

      end;
    finally
      FreeAndNil(AdapterDisplayList);
    end;
    }


    //Version 2
     FetchAdpInfo();

  end;


end;


procedure TMainForm.DoSpinEditEnter(Sender: TObject);
begin
 if Sender is TSpinEdit then
 begin
    TSpinEdit(Sender).SelectAll;
 end;
end;

procedure TMainForm.DoSpinEditKeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
var
  ctrlName:string;
  targetCtrl:TComponent;
begin
 targetCtrl:=nil;
 if (Key=8) or (Key=9) then Exit;
 if (Key>=37) and (Key<=40) then Exit;  //�����
 if Key=46 then Exit; //ɾ����
 if Key=110 then begin
   TSpinEdit(sender).Text:=LeftStr(string(TSpinEdit(sender).Text),length(TSpinEdit(sender).Text)-1);
   key:=0;
   Exit;
 end; //ɾ����

 if ((Key>=48)and (key<=57)) or ((Key>=96)and (key<=105)) then  //���ּ�
 begin
    ctrlName:=TSpinEdit(sender).Name;

    if length(TSpinEdit(sender).Text)=3  then
     begin
       targetCtrl:=FindComponent('SpinEdit'+inttostr(strtoint(ctrlName.Replace('SpinEdit',''))+1));
       if assigned( targetCtrl )then
       begin
        SelectNext(TWinControl(targetCtrl),true,false);
        TWinControl(targetCtrl).SetFocus;
       end;
     end;
 end;
end;

procedure TMainForm.FetchAdpInfo();
var
  AdapterDisplayList:TStrings;
  adptList:TPhysicalAdapterInfoList;
  adptinfo:TPhysicalAdapterInfo;
  nwInfoArr:TArray<TNetworkInfo>;
  nwInfo:TNetworkInfo;

begin
  ComboBox1.Items.clear;
  nwInfoArr:=nil;


  try
    nwInfoArr:=uGetAdapterInfo_V2.GetNetworkInfo;
   { //Version 1
    AdapterDisplayList:=TStringList.Create;
    adptList:=GetCurrentPhysicalAdapterInfo(AdapterDisplayList);
    if Length(adptList)>0 then
    for adptinfo in adptList do
    begin
       SpinEdit1.Text:=adptinfo.IPAddress.Split(['.'])[0];
       SpinEdit2.Text:=adptinfo.IPAddress.Split(['.'])[1];
       SpinEdit3.Text:=adptinfo.IPAddress.Split(['.'])[2];
       SpinEdit4.Text:=adptinfo.IPAddress.Split(['.'])[3];

       SpinEdit5.Text:=adptinfo.Subnetmask.Split(['.'])[0];
       SpinEdit6.Text:=adptinfo.Subnetmask.Split(['.'])[1];
       SpinEdit7.Text:=adptinfo.Subnetmask.Split(['.'])[2];
       SpinEdit8.Text:=adptinfo.Subnetmask.Split(['.'])[3];

       SpinEdit9.Text:=adptinfo.Gateway.Split(['.'])[0];
       SpinEdit10.Text:=adptinfo.Gateway.Split(['.'])[1];
       SpinEdit11.Text:=adptinfo.Gateway.Split(['.'])[2];
       SpinEdit12.Text:=adptinfo.Gateway.Split(['.'])[3];

       SpinEdit13.Text:=adptinfo.Gateway.Split(['.'])[0];
       SpinEdit14.Text:=adptinfo.Gateway.Split(['.'])[1];
       SpinEdit15.Text:=adptinfo.Gateway.Split(['.'])[2];
       SpinEdit16.Text:=adptinfo.Gateway.Split(['.'])[3];

       CheckBox5.Checked:=adptinfo.EnableDHCP;
       CheckBox6.Checked:=adptinfo.EnableDHCP;

       ComboBox1.Items.Assign(AdapterDisplayList);
       ComboBox1.ItemIndex:=ComboBox1.Items.IndexOf(adptinfo.AdapterDisplay);

       ComboBox1.text:= adptinfo.AdapterDisplay;

       if Not CheckBox5.Checked then
       begin
         CheckBox1.Checked:=true;
         CheckBox2.Checked:=true;
         CheckBox3.Checked:=true;
       end
       else
       begin
         CheckBox1.Checked:=false;
         CheckBox2.Checked:=false;
         CheckBox3.Checked:=false;
       end;
    end;
   }
   //Version 2
   if length(nwInfoArr)>0 then
   begin
       for nwInfo in nwInfoArr do
       begin
           ComboBox1.Items.Add(nwInfo.FriendlyName);


           //set IP
           SpinEdit1.Text:=nwInfo.IP_Mask_List[0].IPAddress.Split(['.'])[0];
           SpinEdit2.Text:=nwInfo.IP_Mask_List[0].IPAddress.Split(['.'])[1];
           SpinEdit3.Text:=nwInfo.IP_Mask_List[0].IPAddress.Split(['.'])[2];
           SpinEdit4.Text:=nwInfo.IP_Mask_List[0].IPAddress.Split(['.'])[3];

          //set subnet mask
          SpinEdit5.Text:=nwInfo.IP_Mask_List[0].Mask.Split(['.'])[0];
          SpinEdit6.Text:=nwInfo.IP_Mask_List[0].Mask.Split(['.'])[1];
          SpinEdit7.Text:=nwInfo.IP_Mask_List[0].Mask.Split(['.'])[2];
          SpinEdit8.Text:=nwInfo.IP_Mask_List[0].Mask.Split(['.'])[3];

          //set defautl gateway
         SpinEdit9.Text:=nwInfo.DefaultGateway.Split(['.'])[0];
         SpinEdit10.Text:=nwInfo.DefaultGateway.Split(['.'])[1];
         SpinEdit11.Text:=nwInfo.DefaultGateway.Split(['.'])[2];
         SpinEdit12.Text:=nwInfo.DefaultGateway.Split(['.'])[3];

         // Set preferred DNS server
         SpinEdit13.Text:=nwInfo.DnsServers[0].IP.Split(['.'])[0];
         SpinEdit14.Text:=nwInfo.DnsServers[0].IP.Split(['.'])[1];
         SpinEdit15.Text:=nwInfo.DnsServers[0].IP.Split(['.'])[2];
         SpinEdit16.Text:=nwInfo.DnsServers[0].IP.Split(['.'])[3];

         //Set Alternate DNS Server
         SpinEdit17.Text:=nwInfo.DnsServers[1].IP.Split(['.'])[0];
         SpinEdit18.Text:=nwInfo.DnsServers[1].IP.Split(['.'])[1];
         SpinEdit19.Text:=nwInfo.DnsServers[1].IP.Split(['.'])[2];
         SpinEdit20.Text:=nwInfo.DnsServers[1].IP.Split(['.'])[3];

         CheckBox5.Checked:=nwInfo.DHCPEnabled;
         CheckBox6.Checked:=nwInfo.DHCPEnabled;

         if Not CheckBox5.Checked then
         begin
           CheckBox1.Checked:=true;
           CheckBox2.Checked:=true;
           CheckBox3.Checked:=true;
         end
         else
         begin
           CheckBox1.Checked:=false;
           CheckBox2.Checked:=false;
           CheckBox3.Checked:=false;
         end;

         ComboBox1.ItemIndex:=0;

       end;

   end;

  except
    //FreeAndNil(AdapterDisplayList);
  end;
end;

procedure TMainForm.FormCreate(Sender: TObject);
var
  f: textfile;
  i:integer;
begin
//  ShowMessage(GetLocalIP); //
  data := tstringlist.Create;

 { if not FileExists('data.dat') then
  begin
    AssignFile(f, 'data.dat');
    Rewrite(f);
    CloseFile(f);
    data.Text := '192' + #13 + '168' + #13 + '0' + #13 + '1' + #13 + '255' + #13
      + '255' + #13 + '255' + #13 + '0' + #13 + '192' + #13 + '168' + #13 + '0'
      + #13 + '1' + #13 + '192' + #13 + '168' + #13 + '0' + #13 + '1' + #13 +
      '192' + #13 + '168' + #13 + '0' + #13 + '1' + #13 + '?????';
    data.SaveToFile('data.dat');
  end;}
 // data.Clear;
 { data.LoadFromFile('data.dat');
  SpinEdit1.Text := data[0];
  SpinEdit2.Text := data[1];
  SpinEdit3.Text := data[2];
  SpinEdit4.Text := data[3];
  SpinEdit5.Text := data[4];
  SpinEdit6.Text := data[5];
  SpinEdit7.Text := data[6];
  SpinEdit8.Text := data[7];
  SpinEdit9.Text := data[8];
  SpinEdit10.Text := data[9];
  SpinEdit11.Text := data[10];
  SpinEdit12.Text := data[11];
  SpinEdit13.Text := data[12];
  SpinEdit14.Text := data[13];
  SpinEdit15.Text := data[14];
  SpinEdit16.Text := data[15];
  SpinEdit17.Text := data[16];
  SpinEdit18.Text := data[17];
  SpinEdit19.Text := data[18];
  SpinEdit20.Text := data[19];
  Edit1.Text := data[20];
  }

//  SpeedButton1.Hint := '����ַд���ļ���' + #13 + '�´�����ʱ�����ǽ��Զ����ء�';

  SpeedButton1.Hint := '��������Ϣд���ļ���';

  FetchAdpInfo();
  sleep(200);
  CheckNetworkConnectivity();


   for i:=0 to Self.ComponentCount-1 do
   begin
     if self.Components[i] is TSpinEdit then
     begin
       with TSpinEdit(self.Components[i]) do
       begin
        OnEnter:=DoSpinEditEnter;
        OnKeyUp:=DoSpinEditKeyUp;
       end;
     end;
   end;

end;

procedure TMainForm.FormDestroy(Sender: TObject);
begin
 if Assigned(data) then
   freeandnil(data);
end;

procedure TMainForm.SpeedButton1Click(Sender: TObject);
var
  f: textfile;
begin
  if not FileExists('data.dat') then
  begin
    AssignFile(f, 'data.dat');
    Rewrite(f);
    CloseFile(f);
  end;

  data.Clear;
  data.add(SpinEdit1.Text);
  data.add(SpinEdit2.Text);
  data.add(SpinEdit3.Text);
  data.add(SpinEdit4.Text);
  data.add(SpinEdit5.Text);
  data.add(SpinEdit6.Text);
  data.add(SpinEdit7.Text);
  data.add(SpinEdit8.Text);
  data.add(SpinEdit9.Text);
  data.add(SpinEdit10.Text);
  data.add(SpinEdit11.Text);
  data.add(SpinEdit12.Text);
  data.add(SpinEdit13.Text);
  data.add(SpinEdit14.Text);
  data.add(SpinEdit15.Text);
  data.add(SpinEdit16.Text);
  data.add(SpinEdit17.Text);
  data.add(SpinEdit18.Text);
  data.add(SpinEdit19.Text);
  data.add(SpinEdit20.Text);
  data.add(ComboBox1.Text);

  data.SaveToFile('data.dat');
end;

function AdapterIsConnected(const AdapterName:string;out ACurStatus:string):boolean;
var
  linkList: TStrings;
  sinfo, AdptGUID: string;
  bNetNotConnected:boolean;
  i:integer;
  vparts:TArray<string>;
begin
  linkList := tstringlist.Create;
  try
  bNetNotConnected:=false;
  uNetworkConnection.GetConnectionList(linkList);
  sinfo := trim(linkList.Text);
  ACurStatus:='';
  (*
    {C5A39875-DC6D-44AC-981E-FEF86F90011E}|WLAN|802.11n USB Wireless LAN Card|�ѶϿ�
    {712D66D0-0E9A-4BE6-ADF1-96F360CA0A14}|��̫�� 2|Sangfor SSL VPN CS Support System VNIC|�ѶϿ�
    {B6B5EDAC-CEE3-4774-A2B9-3B644DB5A5A6}|��2̫��|Intel(R) Ethernet Connection (12) I219-V|����ͨ
  *)
 // ShowMessage(sinfo);
  for i := 0 to linkList.Count - 1 do
  begin
   // application.ProcessMessages;sleep(0);
    AdptGUID := copy(linkList[i], 1, pos('|', linkList[i]) - 1);
    if uGetAdapterInfo.IsPhysicalAdapter(AdptGUID) then
    begin
      // ����/������
      if pos('|����ͨ',linkList[i])=0 then
        uNetworkConnection.EnableConnection(AdptGUID, true);
    end;
    if (Not bNetNotConnected)
     and (pos('|����ͨ',linkList[i])>0)
     and (pos('|'+AdapterName+'|',linkList[i])>0) then
    begin
       bNetNotConnected:=true;
       ACurStatus:='����ͨ';
    end
    else
    begin
      vparts:=linkList[i].Split(['|']); // ACurStatus
      ACurStatus:=vparts[high(vparts)];
    end;
  end;
  Result:=bNetNotConnected;
  finally
    FreeAndNil(linkList);
  end;
end;


procedure TMainForm.Button1Click(Sender: TObject);
begin
 RunCMD(' /c rundll32.exe '+'net_properties.dll,ShowConnectionProperties '+ComboBox1.text,false);
end;

function TMainForm.CheckNetworkConnectivity():boolean;
var
  RetVal:boolean;
begin
  RetVal:=false;
  StatusBar1.Panels.Items[0].Text:='������ͼ����';
  TThread.CreateAnonymousThread(procedure
  begin
          TThread.Synchronize(nil,procedure
          var curStatus,resLines:string;
          begin
            curStatus:='';
            while (''=curStatus) or  ('���ڳ���������֤'=curStatus)
                 or  ('��������'=curStatus) or ('������֤�ɹ�'=curStatus)
                 or ('����'=curStatus) or ('�����Ѱγ�'=curStatus) do
            begin
               sleep(0);
               Application.ProcessMessages;
               if ''=curStatus then
                 StatusBar1.Panels.Items[0].Text:='������ͼ����'
               else
                 StatusBar1.Panels.Items[0].Text:=curStatus;
               Application.ProcessMessages;

               if AdapterIsConnected(ComboBox1.Text,curStatus) then
               begin
                  Application.ProcessMessages;
                  if ''=curStatus then
                   StatusBar1.Panels.Items[0].Text:='������ͼ����'
                  else
                  begin
                  //������жϻ����е����⣬��Ҫ��һ���Ż�����
                   if '����ͨ'=curStatus then
                   begin
                      Application.ProcessMessages;
                      StatusBar1.Panels.Items[0].Text:='���Է�������...';

                      try
                        if prHostReachable= upxPingSupportIPV6.Ping('www.baidu.com',resLines) then
                        begin
                          StatusBar1.Panels.Items[0].Text:='��������'+curStatus;
                          RetVal:=true;
                          SpeedButton2.StyleElements:=[];
                          SpeedButton2.Font.Color:=clBlue;
                          SpeedButton2.Caption:='a';
                        end
                        else
                        begin
                            StatusBar1.Panels.Items[0].Text:='���������޷���ͨ��';
                            curStatus:='δ��ͨ';
                            RetVal:=false;
                            SpeedButton2.StyleElements:=[];
                            SpeedButton2.Font.Color:=clRed;
                            SpeedButton2.Caption:='a';
                        end;
                      except
                         StatusBar1.Panels.Items[0].Text:='���������޷���ͨ��';
                         curStatus:='δ��ͨ';
                         RetVal:=false;
                         SpeedButton2.StyleElements:=[];
                         SpeedButton2.Font.Color:=clRed;
                         SpeedButton2.Caption:='a';
                      end;
                      FetchAdpInfo();
                   end;
                  end;


               end;
             end;
             SpeedButton2.Enabled:=true;
             GroupBox2.Enabled:=true;
             BitBtn1.Enabled:=true;
             screen.Cursor:=crdefault;
          end);
  end).Start;
end;

procedure TMainForm.SpeedButton2Click(Sender: TObject);
var
  linkList: TStrings;
  sinfo, AdptGUID: string;
  i: integer;
  bNetNotConnected:boolean;
  totalSec:integer;
begin


  SpeedButton2.Enabled:=false;
  GroupBox2.Enabled:=false;
  BitBtn1.Enabled:=false;
  ComboBox1.clear;
  ComboBox1.ItemIndex:=-1;

  bNetNotConnected:=false;

  screen.Cursor:=crHourGlass;
  linkList := tstringlist.Create;
  uNetworkConnection.GetConnectionList(linkList);
  sinfo := trim(linkList.Text);

  for i := 0 to linkList.Count - 1 do
  begin
    AdptGUID := copy(linkList[i], 1, pos('|', linkList[i]) - 1);
    if uGetAdapterInfo.IsPhysicalAdapter(AdptGUID) then
    begin
      // ����/������
      uNetworkConnection.EnableConnection(AdptGUID, true);
    end;
    if (Not bNetNotConnected) and  (pos('|����ͨ',linkList[i])>0) then
    begin
       bNetNotConnected:=true;
    end;
    sleep(100);
  end;

  totalSec:=0;
  if linkList.Count>0 then
    while True do
    begin
      application.ProcessMessages;

      if totalSec>100 then//����10��Ͳ�ɨ����
      begin
        totalSec:=0;
        break;
      end;

      FetchAdpInfo();
      sleep(20);
      totalSec:=totalSec+1;
      if (ComboBox1.ItemIndex<>-1) then
        break;
    end;
  sleep(100);
  CheckNetworkConnectivity();

  FreeAndNil(linkList);

end;

procedure TMainForm.SpinEdit1MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
   SpinEdit1.SelectAll;
end;

procedure TMainForm.Timer1Timer(Sender: TObject);
begin
  if CheckBox5.Checked then
  begin
    CheckBox1.Checked := false;
    CheckBox2.Checked := false;
    CheckBox1.Enabled := false;
    CheckBox2.Enabled := false;
    SpinEdit1.Enabled := false;
    SpinEdit2.Enabled := false;
    SpinEdit3.Enabled := false;
    SpinEdit4.Enabled := false;
    SpinEdit5.Enabled := false;
    SpinEdit6.Enabled := false;
    SpinEdit7.Enabled := false;
    SpinEdit8.Enabled := false;
    SpinEdit9.Enabled := false;
    SpinEdit10.Enabled := false;
    SpinEdit11.Enabled := false;
    SpinEdit12.Enabled := false;
  end
  else
  begin
    CheckBox1.Enabled := true;
    CheckBox2.Enabled := true;
    SpinEdit1.Enabled := true;
    SpinEdit2.Enabled := true;
    SpinEdit3.Enabled := true;
    SpinEdit4.Enabled := true;
    SpinEdit5.Enabled := true;
    SpinEdit6.Enabled := true;
    SpinEdit7.Enabled := true;
    SpinEdit8.Enabled := true;
    SpinEdit9.Enabled := true;
    SpinEdit10.Enabled := true;
    SpinEdit11.Enabled := true;
    SpinEdit12.Enabled := true;
  end;

  if CheckBox6.Checked then
  begin
    CheckBox3.Checked := false;
    CheckBox4.Checked := false;
    CheckBox3.Enabled := false;
    CheckBox4.Enabled := false;
    SpinEdit13.Enabled := false;
    SpinEdit14.Enabled := false;
    SpinEdit15.Enabled := false;
    SpinEdit16.Enabled := false;
    SpinEdit17.Enabled := false;
    SpinEdit18.Enabled := false;
    SpinEdit19.Enabled := false;
    SpinEdit20.Enabled := false;
  end
  else
  begin
    CheckBox3.Enabled := true;
    CheckBox4.Enabled := true;
    SpinEdit13.Enabled := true;
    SpinEdit14.Enabled := true;
    SpinEdit15.Enabled := true;
    SpinEdit16.Enabled := true;
    SpinEdit17.Enabled := true;
    SpinEdit18.Enabled := true;
    SpinEdit19.Enabled := true;
    SpinEdit20.Enabled := true;
  end;

  if (CheckBox1.Checked) or (CheckBox2.Checked) then
    CheckBox5.Enabled := false
  else
    CheckBox5.Enabled := true;
  if (CheckBox3.Checked) or (CheckBox4.Checked) then
    CheckBox6.Enabled := false
  else
    CheckBox6.Enabled := true;

  if CheckBox2.Checked then
    CheckBox1.Checked := true;
  if CheckBox4.Checked then
    CheckBox3.Checked := true;
end;

end.
