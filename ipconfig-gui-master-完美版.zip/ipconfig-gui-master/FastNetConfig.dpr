program FastNetConfig;

{$R *.dres}

uses
  Forms,
  Unit1 in 'Unit1.pas' {MainForm},
  uGetAdapterInfo in 'uGetAdapterInfo.pas',
  uNetworkConnection in 'uNetworkConnection.pas',
  Vcl.Themes,
  Vcl.Styles;

{$R *.res}

begin
  system.ReportMemoryLeaksOnShutdown:=true;
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  TStyleManager.TrySetStyle('Luna');
  Application.HintPause:=0;
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
