unit uNetworkConnection;

interface

uses Windows, Messages, SysUtils, Variants, Classes, Graphics, ActiveX,
  ComObj, Contnrs;

const
  CLSID_ConnectionManager: TGUID = '{BA126AD1-2166-11D1-B1D0-00805FC1270E}';
  IID_INetConnectionManager: TGUID = '{C08956A2-1CD3-11D1-B1C5-00805FC1270E}';

type
  NETCONMGR_ENUM_FLAGS = (NCME_DEFAULT);

  NETCON_STATUS = (
    NCS_DISCONNECTED{�����ѶϿ�����},
    NCS_CONNECTING{�������ڽ�������},
    NCS_CONNECTED{���Ӵ�������״̬},
    NCS_DISCONNECTING{�������ڶϿ�����},
    NCS_HARDWARE_NOT_PRESENT{���ӵ�Ӳ������������ӿڿ� (NIC) ��������},
    NCS_HARDWARE_DISABLED{���ӵ�Ӳ�����ڣ���δ����},
    NCS_HARDWARE_MALFUNCTION{���ӵ�Ӳ���з����˹���},
    NCS_MEDIA_DISCONNECTED{ý�壨����������£��Ͽ�����},
    NCS_AUTHENTICATING{�������ڵȴ�������֤����},
    NCS_AUTHENTICATION_SUCCEEDED{������֤�ڴ������ϳɹ�},
    NCS_AUTHENTICATION_FAILED{��������������֤ʧ��},
    NCS_INVALID_ADDRESS{��ַ��Ч},
    NCS_CREDENTIALS_REQUIRED {��Ҫ��ȫƾ��}
     );

  NETCON_MEDIATYPE = (NCM_NONE, NCM_DIRECT, NCM_ISDN, NCM_LAN, NCM_PHONE,
    NCM_TUNNEL, NCM_PPPOE, NCM_BRIDGE, NCM_SHAREDACCESSHOST_LAN,
    NCM_SHAREDACCESSHOST_RAS);

  PNETCON_PROPERTIES = ^NETCON_PROPERTIES;

  NETCON_PROPERTIES = record
    guidId: TGUID;
    pszwName: LPWSTR; // array [0..255] of WCHAR;
    pszwDeviceName: LPWSTR;
    Status: NETCON_STATUS;
    MediaType: NETCON_MEDIATYPE;
    dwCharacter: DWORD;
    clsidThisObject: TGUID;
    clsidUiObject: TGUID;
  end;

  INetConnectionManager = interface;
  INetConnection = interface;
  IEnumNetConnection = interface;

  INetConnectionManager = interface(IUnknown)
    ['{C08956A2-1CD3-11D1-B1C5-00805FC1270E}']
    function EnumConnections(flag: NETCONMGR_ENUM_FLAGS;
      out ppv: IEnumNetConnection): HRESULT; stdcall;
  end;

  IEnumNetConnection = interface(IUnknown)
    ['{C08956A0-1CD3-11D1-B1C5-00805FC1270E}']
    function Next(celt: DWORD; out rgelt: INetConnection; pceltFetched: PULONG)
      : HRESULT; stdcall;
    function Skip(celt: ULONG): HRESULT; stdcall;
    function Reset(): HRESULT; stdcall;
    function Clone(out ppenum: IEnumNetConnection): HRESULT; stdcall;
  end;

  INetConnection = interface(IUnknown)
    ['{C08956A1-1CD3-11D1-B1C5-00805FC1270E}']
    function Connect(): HRESULT; stdcall;
    function Disconnect(): HRESULT; stdcall;
    function Delete(): HRESULT; stdcall;
    function Duplicate(pszwDuplicateName: LPCWSTR; out ppCon: INetConnection)
      : HRESULT; stdcall;
    function GetProperties(out ppProps: PNETCON_PROPERTIES): HRESULT; stdcall;
    function GetUiObjectClassId(out pclsid: TGUID): HRESULT; stdcall;
    function Rename(pszwNewName: LPCWSTR): HRESULT; stdcall;
  end; // Global functions


 //���ķ���1 ��ȡ��������
procedure GetConnectionList(pList: TStrings);

  //���ķ���2 ���û������������
function EnableConnection(Guid: String; bEnable: Boolean): Integer;

implementation

procedure GetConnectionList(pList: TStrings);
var
  pManager: INetConnectionManager;
  pEnum: IEnumNetConnection;
  pConnection: INetConnection;
  celtFetched: DWORD;
  pProperties: PNETCON_PROPERTIES;
  Status: String;
begin
  CoCreateInstance(CLSID_ConnectionManager, nil, CLSCTX_SERVER,IID_INetConnectionManager, pManager);

  if SUCCEEDED(pManager.EnumConnections(NCME_DEFAULT, pEnum)) then
  begin
    while (pEnum.Next(1, pConnection, @celtFetched) = S_OK) do
    begin
      pConnection.GetProperties(pProperties);

      case pProperties.Status of
        NCS_CONNECTED:
        begin
           Status := '����ͨ';  //CONNECTED
        end;
        NCS_DISCONNECTED:
          Status := '�ѶϿ�'; //DISCONNECTED
        NCS_CONNECTING:
          Status := '��������';   //CONNECTING
        NCS_HARDWARE_DISABLED:
          Status := '�ѽ���';   //DISABLED
        NCS_AUTHENTICATING:
          Status := '���ڳ���������֤';
        NCS_AUTHENTICATION_SUCCEEDED:
          Status := '������֤�ɹ�';
        NCS_AUTHENTICATION_FAILED:
          Status := '������֤ʧ��';
        NCS_DISCONNECTING:
         Status := '���ڶϿ�����';
        NCS_HARDWARE_MALFUNCTION:
          Status := 'Ӳ������';
        NCS_HARDWARE_NOT_PRESENT:
          Status := 'Ӳ��������';
        NCS_MEDIA_DISCONNECTED:
           Status := '�����Ѱγ�';
        NCS_INVALID_ADDRESS:
           Status := '��ַ��Ч';
        NCS_CREDENTIALS_REQUIRED:
           Status := '��Ҫ��ȫƾ��';

      else
        Status := '����';  //Others
      end;
      pList.Add(Format('%s|%s|%s|%s', [GUIDToString(pProperties.guidId),
        pProperties.pszwName, pProperties.pszwDeviceName, Status]));
    end;
  end;
end;

// This method will enable/disable the network connection similar to  the GUI code.
// EnableConnection(L"Local Area Connection", true);
//
function EnableConnection(Guid: String; bEnable: Boolean): Integer;
var
  LPNcFreeNetconProperties: procedure(pProps: PNETCON_PROPERTIES)stdcall;
  // LPIEnumNetConnection_EnumConnections : procedure(myob : IEnumNetConnectionj, NETCONMGR_ENUM_FLAGS flags, IEnumNetConnection * * ppEnum);
  hres: HRESULT;
  pMan: INetConnectionManager;
  pEnum: IEnumNetConnection;
  pCon: INetConnection;
  count: DWORD;
  done: Integer;
  hmod: HMODULE;
  pProps: PNETCON_PROPERTIES;
begin
  result := 0;
  hmod := LoadLibrary('netshell.dll');
  if (hmod = 0) then
    exit;
  @LPNcFreeNetconProperties := GetProcAddress(hmod, 'NcFreeNetconProperties');
  if (@LPNcFreeNetconProperties = nil) then
  begin
    FreeLibrary(hmod);
    exit;
  end;
  pMan := nil;
  hres := CoCreateInstance(CLSID_ConnectionManager, nil, CLSCTX_ALL,
    IID_INetConnectionManager, pMan);
  if (SUCCEEDED(hres)) then
  begin
    hres := pMan.EnumConnections(NCME_DEFAULT, pEnum);
    if (SUCCEEDED(hres)) then
    begin
      done := 0;
      Guid := LowerCase(Guid);
      while ((pEnum.Next(1, pCon, @count) = S_OK) and (done = 0)) do
      begin
        pCon.GetProperties(pProps);
        if (SUCCEEDED(hres)) then
        begin

          if (LowerCase(GUIDToString(pProps.guidId)) = Guid) then
          begin
            // messagebox(0,pchar(GuidToString(pProps.guidId)),'guid',1);
            if (bEnable) then
            begin
              result := pCon.Connect(); // ����(�ָ�)����
            end
            else
            begin
              result := pCon.Disconnect(); // �Ͽ�����
            end;
            done := 1;
          end; // END if (wcsstr(pProps->...
          LPNcFreeNetconProperties(pProps);
          // pCon._Release();
        end;
      end; // END while
      // pEnum._Release();
    end;
    // pMan._Release();
  end;
  FreeLibrary(hmod);
end;

end.
